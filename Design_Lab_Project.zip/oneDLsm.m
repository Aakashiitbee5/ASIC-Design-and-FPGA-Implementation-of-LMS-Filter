clc;
clear all;
close all;
global x; global y; global yout;
nx=256;
%offset=2000;
offset=0;
fs=(nx-1)/(10*pi);
t=0:1/fs:(nx-1+offset)/fs;

%t = linspace(0,10*pi,nx)';
f_chirp = 1/16;
f_chirp = 1/16;                  % Target frequency
%y= sin(pi*f_chirp*t);  % Desired Signal Linear chirp
[y,fs]=audioread('CantinaBand3.wav');
y=y';

%x=sin(pi*f_chirp*t)+rand(1,length(t));

x=y+randn(size(y));
order=200;
w=zeros(order,1);
mu=0.006;%step size
for i=1:length(x)-order
    buffer=x(i:i+order-1);
    yout(i)=buffer*w;
    error(i)=y(i)-buffer*w;
    w=w+(buffer.*mu*error(i))';%update weight
end
figure(1)
plot(y);
figure(2)
plot(x);
figure(3)
plot(yout);

